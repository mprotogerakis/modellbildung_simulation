/* Initial State Set */
#include "Wassertank_model.h"
#include "Wassertank_11mix.h"
#include "Wassertank_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void Wassertank_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

