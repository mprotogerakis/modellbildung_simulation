/* DAE residuals is empty */
 #include "Wassertank_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int Wassertank_initializeDAEmodeData(DATA* data, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
