/* update bound parameters and variable attributes (start, nominal, min, max) */
#include "Wassertank_model.h"
#if defined(__cplusplus)
extern "C" {
#endif


/*
equation index: 26
type: SIMPLE_ASSIGN
$START.limIntegrator.y = limIntegrator.y_start
*/
static void Wassertank_eqFunction_26(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,26};
  (data->modelData->realVarsData[0] /* limIntegrator.y STATE(1) */).attribute .start = (data->simulationInfo->realParameter[4] /* limIntegrator.y_start PARAM */);
    (data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */) = (data->modelData->realVarsData[0] /* limIntegrator.y STATE(1) */).attribute .start;
    infoStreamPrint(LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[0].info /* limIntegrator.y */.name, (modelica_real) (data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */));
  TRACE_POP
}
OMC_DISABLE_OPT
int Wassertank_updateBoundVariableAttributes(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  /* min ******************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating min-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* max ******************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating max-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* nominal **************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating nominal-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* start ****************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating primary start-values");
  Wassertank_eqFunction_26(data, threadData);
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  TRACE_POP
  return 0;
}

void Wassertank_updateBoundParameters_0(DATA *data, threadData_t *threadData);

/*
equation index: 28
type: SIMPLE_ASSIGN
limIntegrator.y_start = initial_hoehe
*/
OMC_DISABLE_OPT
static void Wassertank_eqFunction_28(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,28};
  (data->simulationInfo->realParameter[4] /* limIntegrator.y_start PARAM */) = (data->simulationInfo->realParameter[0] /* initial_hoehe PARAM */);
  TRACE_POP
}

/*
equation index: 33
type: SIMPLE_ASSIGN
limIntegrator.outMax = max_hoehe
*/
OMC_DISABLE_OPT
static void Wassertank_eqFunction_33(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,33};
  (data->simulationInfo->realParameter[2] /* limIntegrator.outMax PARAM */) = (data->simulationInfo->realParameter[5] /* max_hoehe PARAM */);
  TRACE_POP
}
extern void Wassertank_eqFunction_2(DATA *data, threadData_t *threadData);

extern void Wassertank_eqFunction_1(DATA *data, threadData_t *threadData);


/*
equation index: 36
type: ALGORITHM

  assert(limIntegrator.initType >= Modelica.Blocks.Types.Init.NoInit and limIntegrator.initType <= Modelica.Blocks.Types.Init.InitialOutput, "Variable violating min/max constraint: Modelica.Blocks.Types.Init.NoInit <= limIntegrator.initType <= Modelica.Blocks.Types.Init.InitialOutput, has value: " + String(limIntegrator.initType, "d"));
*/
OMC_DISABLE_OPT
static void Wassertank_eqFunction_36(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,36};
  modelica_boolean tmp0;
  modelica_boolean tmp1;
  static const MMC_DEFSTRINGLIT(tmp2,155,"Variable violating min/max constraint: Modelica.Blocks.Types.Init.NoInit <= limIntegrator.initType <= Modelica.Blocks.Types.Init.InitialOutput, has value: ");
  modelica_string tmp3;
  modelica_metatype tmpMeta4;
  static int tmp5 = 0;
  if(!tmp5)
  {
    tmp0 = GreaterEq((data->simulationInfo->integerParameter[0] /* limIntegrator.initType PARAM */),1);
    tmp1 = LessEq((data->simulationInfo->integerParameter[0] /* limIntegrator.initType PARAM */),4);
    if(!(tmp0 && tmp1))
    {
      tmp3 = modelica_integer_to_modelica_string_format((data->simulationInfo->integerParameter[0] /* limIntegrator.initType PARAM */), (modelica_string) mmc_strings_len1[100]);
      tmpMeta4 = stringAppend(MMC_REFSTRINGLIT(tmp2),tmp3);
      {
        const char* assert_cond = "(limIntegrator.initType >= Modelica.Blocks.Types.Init.NoInit and limIntegrator.initType <= Modelica.Blocks.Types.Init.InitialOutput)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/proto/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Continuous.mo",136,5,138,64,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta4));
        } else {
          FILE_INFO info = {"C:/Users/proto/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Continuous.mo",136,5,138,64,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta4));
        }
      }
      tmp5 = 1;
    }
  }
  TRACE_POP
}
OMC_DISABLE_OPT
void Wassertank_updateBoundParameters_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  Wassertank_eqFunction_28(data, threadData);
  Wassertank_eqFunction_33(data, threadData);
  Wassertank_eqFunction_2(data, threadData);
  Wassertank_eqFunction_1(data, threadData);
  Wassertank_eqFunction_36(data, threadData);
  TRACE_POP
}
OMC_DISABLE_OPT
int Wassertank_updateBoundParameters(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  (data->simulationInfo->booleanParameter[0]/* limIntegrator.limitsAtInit PARAM */) = 1;
  data->modelData->booleanParameterData[0].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[1]/* limIntegrator.strict PARAM */) = 0;
  data->modelData->booleanParameterData[1].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[2]/* limIntegrator.use_reset PARAM */) = 0;
  data->modelData->booleanParameterData[2].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[3]/* limIntegrator.use_set PARAM */) = 0;
  data->modelData->booleanParameterData[3].time_unvarying = 1;
  (data->simulationInfo->integerParameter[0]/* limIntegrator.initType PARAM */) = 3;
  data->modelData->integerParameterData[0].time_unvarying = 1;
  Wassertank_updateBoundParameters_0(data, threadData);
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

