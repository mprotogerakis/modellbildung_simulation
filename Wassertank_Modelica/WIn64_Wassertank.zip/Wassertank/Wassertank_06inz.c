/* Initialization */
#include "Wassertank_model.h"
#include "Wassertank_11mix.h"
#include "Wassertank_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void Wassertank_functionInitialEquations_0(DATA *data, threadData_t *threadData);

/*
equation index: 1
type: SIMPLE_ASSIGN
limIntegrator.local_reset = false
*/
void Wassertank_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  (data->localData[0]->booleanVars[4] /* limIntegrator.local_reset DISCRETE */) = 0;
  TRACE_POP
}

/*
equation index: 2
type: SIMPLE_ASSIGN
limIntegrator.local_set = 0.0
*/
void Wassertank_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  (data->localData[0]->realVars[2] /* limIntegrator.local_set variable */) = 0.0;
  TRACE_POP
}
extern void Wassertank_eqFunction_16(DATA *data, threadData_t *threadData);


/*
equation index: 4
type: SIMPLE_ASSIGN
limIntegrator.y = limIntegrator.y_start
*/
void Wassertank_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  (data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */) = (data->simulationInfo->realParameter[4] /* limIntegrator.y_start PARAM */);
  TRACE_POP
}
extern void Wassertank_eqFunction_18(DATA *data, threadData_t *threadData);

extern void Wassertank_eqFunction_21(DATA *data, threadData_t *threadData);

extern void Wassertank_eqFunction_20(DATA *data, threadData_t *threadData);

extern void Wassertank_eqFunction_19(DATA *data, threadData_t *threadData);

extern void Wassertank_eqFunction_17(DATA *data, threadData_t *threadData);


/*
equation index: 10
type: SIMPLE_ASSIGN
$PRE.highSignal = $START.highSignal
*/
void Wassertank_eqFunction_10(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,10};
  (data->simulationInfo->booleanVarsPre[3] /* highSignal DISCRETE */) = (data->modelData->booleanVarsData[3] /* highSignal DISCRETE */).attribute .start;
  TRACE_POP
}

/*
equation index: 11
type: SIMPLE_ASSIGN
highSignal = $PRE.highSignal
*/
void Wassertank_eqFunction_11(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,11};
  (data->localData[0]->booleanVars[3] /* highSignal DISCRETE */) = (data->simulationInfo->booleanVarsPre[3] /* highSignal DISCRETE */);
  TRACE_POP
}
extern void Wassertank_eqFunction_25(DATA *data, threadData_t *threadData);


/*
equation index: 13
type: SIMPLE_ASSIGN
$PRE.lowSignal = $START.lowSignal
*/
void Wassertank_eqFunction_13(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,13};
  (data->simulationInfo->booleanVarsPre[5] /* lowSignal DISCRETE */) = (data->modelData->booleanVarsData[5] /* lowSignal DISCRETE */).attribute .start;
  TRACE_POP
}

/*
equation index: 14
type: SIMPLE_ASSIGN
lowSignal = $PRE.lowSignal
*/
void Wassertank_eqFunction_14(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,14};
  (data->localData[0]->booleanVars[5] /* lowSignal DISCRETE */) = (data->simulationInfo->booleanVarsPre[5] /* lowSignal DISCRETE */);
  TRACE_POP
}
extern void Wassertank_eqFunction_23(DATA *data, threadData_t *threadData);

OMC_DISABLE_OPT
void Wassertank_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  Wassertank_eqFunction_1(data, threadData);
  Wassertank_eqFunction_2(data, threadData);
  Wassertank_eqFunction_16(data, threadData);
  Wassertank_eqFunction_4(data, threadData);
  Wassertank_eqFunction_18(data, threadData);
  Wassertank_eqFunction_21(data, threadData);
  Wassertank_eqFunction_20(data, threadData);
  Wassertank_eqFunction_19(data, threadData);
  Wassertank_eqFunction_17(data, threadData);
  Wassertank_eqFunction_10(data, threadData);
  Wassertank_eqFunction_11(data, threadData);
  Wassertank_eqFunction_25(data, threadData);
  Wassertank_eqFunction_13(data, threadData);
  Wassertank_eqFunction_14(data, threadData);
  Wassertank_eqFunction_23(data, threadData);
  TRACE_POP
}

int Wassertank_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  Wassertank_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}

/* No Wassertank_functionInitialEquations_lambda0 function */

int Wassertank_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

