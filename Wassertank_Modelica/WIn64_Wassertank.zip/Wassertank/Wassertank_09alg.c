/* Algebraic */
#include "Wassertank_model.h"

#ifdef __cplusplus
extern "C" {
#endif


/* forwarded equations */
extern void Wassertank_eqFunction_18(DATA* data, threadData_t *threadData);
extern void Wassertank_eqFunction_19(DATA* data, threadData_t *threadData);
extern void Wassertank_eqFunction_20(DATA* data, threadData_t *threadData);
extern void Wassertank_eqFunction_21(DATA* data, threadData_t *threadData);
extern void Wassertank_eqFunction_23(DATA* data, threadData_t *threadData);
extern void Wassertank_eqFunction_25(DATA* data, threadData_t *threadData);

static void functionAlg_system0(DATA *data, threadData_t *threadData)
{
  {
    Wassertank_eqFunction_18(data, threadData);
    threadData->lastEquationSolved = 18;
  }
  {
    Wassertank_eqFunction_19(data, threadData);
    threadData->lastEquationSolved = 19;
  }
  {
    Wassertank_eqFunction_20(data, threadData);
    threadData->lastEquationSolved = 20;
  }
  {
    Wassertank_eqFunction_21(data, threadData);
    threadData->lastEquationSolved = 21;
  }
  {
    Wassertank_eqFunction_23(data, threadData);
    threadData->lastEquationSolved = 23;
  }
  {
    Wassertank_eqFunction_25(data, threadData);
    threadData->lastEquationSolved = 25;
  }
}
/* for continuous time variables */
int Wassertank_functionAlgebraics(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_ALGEBRAICS);
#endif
  data->simulationInfo->callStatistics.functionAlgebraics++;

  Wassertank_function_savePreSynchronous(data, threadData);
  
  functionAlg_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_ALGEBRAICS);
#endif

  TRACE_POP
  return 0;
}

#ifdef __cplusplus
}
#endif
