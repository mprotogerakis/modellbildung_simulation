/* Linearization */
#include "Wassertank_model.h"
#if defined(__cplusplus)
extern "C" {
#endif
const char *Wassertank_linear_model_frame()
{
  return "model linearized_model \"Wassertank\" \n  parameter Integer n = 1 \"number of states\";\n  parameter Integer m = 2 \"number of inputs\";\n  parameter Integer p = 3 \"number of outputs\";\n"
  "  parameter Real x0[n] = %s;\n"
  "  parameter Real u0[m] = %s;\n"
  "\n"
  "  parameter Real A[n, n] =\n\t[%s];\n\n"
  "  parameter Real B[n, m] =\n\t[%s];\n\n"
  "  parameter Real C[p, n] =\n\t[%s];\n\n"
  "  parameter Real D[p, m] =\n\t[%s];\n\n"
  "\n"
  "  Real x[n](start=x0);\n"
  "  input Real u[m](start=u0);\n"
  "  output Real y[p];\n"
  "\n"
  "  Real 'x_limIntegrator.y' = x[1];\n"
  "  Real 'u_u_in' = u[1];\n""  Real 'u_u_out' = u[2];\n"
  "  Real 'y_y' = y[1];\n""  Real 'y_y_high' = y[2];\n""  Real 'y_y_low' = y[3];\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linearized_model;\n";
}
const char *Wassertank_linear_model_datarecovery_frame()
{
  return "model linearized_model \"Wassertank\" \n parameter Integer n = 1 \"number of states\";\n  parameter Integer m = 2 \"number of inputs\";\n  parameter Integer p = 3 \"number of outputs\";\n  parameter Integer nz = 5 \"data recovery variables\";\n"
  "  parameter Real x0[1] = %s;\n"
  "  parameter Real u0[2] = %s;\n"
  "  parameter Real z0[5] = %s;\n"
  "\n"
  "  parameter Real A[n, n] =\n\t[%s];\n\n"
  "  parameter Real B[n, m] =\n\t[%s];\n\n"
  "  parameter Real C[p, n] =\n\t[%s];\n\n"
  "  parameter Real D[p, m] =\n\t[%s];\n\n"
  "  parameter Real Cz[nz, n] =\n\t[%s];\n\n"
  "  parameter Real Dz[nz, m] =\n\t[%s];\n\n"
  "\n"
  "  Real x[n](start=x0);\n"
  "  input Real u[m](start=u0);\n"
  "  output Real y[p];\n"
  "  output Real z[nz];\n"
  "\n"
  "  Real 'x_limIntegrator.y' = x[1];\n"
  "  Real 'u_u_in' = u[1];\n""  Real 'u_u_out' = u[2];\n"
  "  Real 'y_y' = y[1];\n""  Real 'y_y_high' = y[2];\n""  Real 'y_y_low' = y[3];\n"
  "  Real 'z_limIntegrator.local_set' = z[1];\n""  Real 'z_limIntegrator.u' = z[2];\n""  Real 'z_u_in' = z[3];\n""  Real 'z_u_out' = z[4];\n""  Real 'z_y' = z[5];\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linearized_model;\n";
}
#if defined(__cplusplus)
}
#endif

