/* Events: Sample, Zero Crossings, Relations, Discrete Changes */
#include "Wassertank_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* Initializes the raw time events of the simulation using the now
   calcualted parameters. */
void Wassertank_function_initSample(DATA *data, threadData_t *threadData)
{
  long i=0;
}

const char *Wassertank_zeroCrossingDescription(int i, int **out_EquationIndexes)
{
  static const char *res[] = {"y <= 0.001",
  "y >= max_hoehe - 0.001",
  "not y <= 0.001",
  "not y >= max_hoehe - 0.001",
  "limIntegrator.y < limIntegrator.outMin and limIntegrator.k * limIntegrator.u < 0.0 or limIntegrator.y > limIntegrator.outMax and limIntegrator.k * limIntegrator.u > 0.0"};
  static const int occurEqs0[] = {1,19};
  static const int occurEqs1[] = {1,20};
  static const int occurEqs2[] = {1,21};
  static const int occurEqs3[] = {1,21};
  static const int occurEqs4[] = {1,17};
  static const int *occurEqs[] = {occurEqs0,occurEqs1,occurEqs2,occurEqs3,occurEqs4};
  *out_EquationIndexes = (int*) occurEqs[i];
  return res[i];
}

/* forwarded equations */
extern void Wassertank_eqFunction_16(DATA* data, threadData_t *threadData);
extern void Wassertank_eqFunction_17(DATA* data, threadData_t *threadData);
extern void Wassertank_eqFunction_18(DATA* data, threadData_t *threadData);

int Wassertank_function_ZeroCrossingsEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->callStatistics.functionZeroCrossingsEquations++;

  Wassertank_eqFunction_16(data, threadData);

  Wassertank_eqFunction_17(data, threadData);

  Wassertank_eqFunction_18(data, threadData);
  
  TRACE_POP
  return 0;
}

int Wassertank_function_ZeroCrossings(DATA *data, threadData_t *threadData, double *gout)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;

  modelica_boolean tmp0;
  modelica_boolean tmp1;
  modelica_boolean tmp2;
  modelica_boolean tmp3;
  modelica_boolean tmp4;
  modelica_boolean tmp5;
  modelica_boolean tmp6;
  modelica_boolean tmp7;

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_ZC);
#endif
  data->simulationInfo->callStatistics.functionZeroCrossings++;

  tmp0 = LessEqZC((data->localData[0]->realVars[6] /* y variable */), 0.001, data->simulationInfo->storedRelations[0]);
  gout[0] = (tmp0) ? 1 : -1;

  tmp1 = GreaterEqZC((data->localData[0]->realVars[6] /* y variable */), (data->simulationInfo->realParameter[5] /* max_hoehe PARAM */) - 0.001, data->simulationInfo->storedRelations[1]);
  gout[1] = (tmp1) ? 1 : -1;

  tmp2 = LessEqZC((data->localData[0]->realVars[6] /* y variable */), 0.001, data->simulationInfo->storedRelations[0]);
  gout[2] = ((!tmp2)) ? 1 : -1;

  tmp3 = GreaterEqZC((data->localData[0]->realVars[6] /* y variable */), (data->simulationInfo->realParameter[5] /* max_hoehe PARAM */) - 0.001, data->simulationInfo->storedRelations[1]);
  gout[3] = ((!tmp3)) ? 1 : -1;

  tmp4 = LessZC((data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */), (data->simulationInfo->realParameter[3] /* limIntegrator.outMin PARAM */), data->simulationInfo->storedRelations[2]);
  tmp5 = LessZC(((data->simulationInfo->realParameter[1] /* limIntegrator.k PARAM */)) * ((data->localData[0]->realVars[3] /* limIntegrator.u variable */)), 0.0, data->simulationInfo->storedRelations[3]);
  tmp6 = GreaterZC((data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */), (data->simulationInfo->realParameter[2] /* limIntegrator.outMax PARAM */), data->simulationInfo->storedRelations[4]);
  tmp7 = GreaterZC(((data->simulationInfo->realParameter[1] /* limIntegrator.k PARAM */)) * ((data->localData[0]->realVars[3] /* limIntegrator.u variable */)), 0.0, data->simulationInfo->storedRelations[5]);
  gout[4] = (((tmp4 && tmp5) || (tmp6 && tmp7))) ? 1 : -1;

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_ZC);
#endif

  TRACE_POP
  return 0;
}

const char *Wassertank_relationDescription(int i)
{
  const char *res[] = {"y <= 0.001",
  "y >= max_hoehe - 0.001",
  "limIntegrator.y < limIntegrator.outMin",
  "limIntegrator.k * limIntegrator.u < 0.0",
  "limIntegrator.y > limIntegrator.outMax",
  "limIntegrator.k * limIntegrator.u > 0.0"};
  return res[i];
}

int Wassertank_function_updateRelations(DATA *data, threadData_t *threadData, int evalforZeroCross)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;

  modelica_boolean tmp8;
  modelica_boolean tmp9;
  modelica_boolean tmp10;
  modelica_boolean tmp11;
  modelica_boolean tmp12;
  modelica_boolean tmp13;
  
  if(evalforZeroCross) {
    tmp8 = LessEqZC((data->localData[0]->realVars[6] /* y variable */), 0.001, data->simulationInfo->storedRelations[0]);
    data->simulationInfo->relations[0] = tmp8;

    tmp9 = GreaterEqZC((data->localData[0]->realVars[6] /* y variable */), (data->simulationInfo->realParameter[5] /* max_hoehe PARAM */) - 0.001, data->simulationInfo->storedRelations[1]);
    data->simulationInfo->relations[1] = tmp9;

    tmp10 = LessZC((data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */), (data->simulationInfo->realParameter[3] /* limIntegrator.outMin PARAM */), data->simulationInfo->storedRelations[2]);
    data->simulationInfo->relations[2] = tmp10;

    tmp11 = LessZC(((data->simulationInfo->realParameter[1] /* limIntegrator.k PARAM */)) * ((data->localData[0]->realVars[3] /* limIntegrator.u variable */)), 0.0, data->simulationInfo->storedRelations[3]);
    data->simulationInfo->relations[3] = tmp11;

    tmp12 = GreaterZC((data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */), (data->simulationInfo->realParameter[2] /* limIntegrator.outMax PARAM */), data->simulationInfo->storedRelations[4]);
    data->simulationInfo->relations[4] = tmp12;

    tmp13 = GreaterZC(((data->simulationInfo->realParameter[1] /* limIntegrator.k PARAM */)) * ((data->localData[0]->realVars[3] /* limIntegrator.u variable */)), 0.0, data->simulationInfo->storedRelations[5]);
    data->simulationInfo->relations[5] = tmp13;
  } else {
    data->simulationInfo->relations[0] = ((data->localData[0]->realVars[6] /* y variable */) <= 0.001);

    data->simulationInfo->relations[1] = ((data->localData[0]->realVars[6] /* y variable */) >= (data->simulationInfo->realParameter[5] /* max_hoehe PARAM */) - 0.001);

    data->simulationInfo->relations[2] = ((data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */) < (data->simulationInfo->realParameter[3] /* limIntegrator.outMin PARAM */));

    data->simulationInfo->relations[3] = (((data->simulationInfo->realParameter[1] /* limIntegrator.k PARAM */)) * ((data->localData[0]->realVars[3] /* limIntegrator.u variable */)) < 0.0);

    data->simulationInfo->relations[4] = ((data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */) > (data->simulationInfo->realParameter[2] /* limIntegrator.outMax PARAM */));

    data->simulationInfo->relations[5] = (((data->simulationInfo->realParameter[1] /* limIntegrator.k PARAM */)) * ((data->localData[0]->realVars[3] /* limIntegrator.u variable */)) > 0.0);
  }
  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

