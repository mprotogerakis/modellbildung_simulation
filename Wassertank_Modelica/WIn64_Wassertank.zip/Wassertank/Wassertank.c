/* Main Simulation File */

#if defined(__cplusplus)
extern "C" {
#endif

#include "Wassertank_model.h"
#include "simulation/solver/events.h"

/* FIXME these defines are ugly and hard to read, why not use direct function pointers instead? */
#define prefixedName_performSimulation Wassertank_performSimulation
#define prefixedName_updateContinuousSystem Wassertank_updateContinuousSystem
#include <simulation/solver/perform_simulation.c.inc>

#define prefixedName_performQSSSimulation Wassertank_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c.inc>


/* dummy VARINFO and FILEINFO */
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;

int Wassertank_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  (data->localData[0]->realVars[4] /* u_in variable */) = data->simulationInfo->inputVars[0];
  (data->localData[0]->realVars[5] /* u_out variable */) = data->simulationInfo->inputVars[1];
  
  TRACE_POP
  return 0;
}

int Wassertank_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->inputVars[0] = data->modelData->realVarsData[4].attribute.start;
  data->simulationInfo->inputVars[1] = data->modelData->realVarsData[5].attribute.start;
  
  TRACE_POP
  return 0;
}

int Wassertank_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->modelData->realVarsData[4].attribute.start = data->simulationInfo->inputVars[0];
  data->modelData->realVarsData[5].attribute.start = data->simulationInfo->inputVars[1];
  
  TRACE_POP
  return 0;
}

int Wassertank_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  names[0] = (char *) data->modelData->realVarsData[4].info.name;
  names[1] = (char *) data->modelData->realVarsData[5].info.name;
  
  TRACE_POP
  return 0;
}

int Wassertank_data_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  TRACE_POP
  return 0;
}

int Wassertank_dataReconciliationInputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Wassertank_dataReconciliationUnmeasuredVariables(DATA *data, char ** names)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Wassertank_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->outputVars[0] = (data->localData[0]->realVars[6] /* y variable */);
  
  TRACE_POP
  return 0;
}

int Wassertank_setc_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Wassertank_setb_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/*
equation index: 16
type: SIMPLE_ASSIGN
limIntegrator.u = u_in - u_out
*/
void Wassertank_eqFunction_16(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,16};
  (data->localData[0]->realVars[3] /* limIntegrator.u variable */) = (data->localData[0]->realVars[4] /* u_in variable */) - (data->localData[0]->realVars[5] /* u_out variable */);
  TRACE_POP
}
/*
equation index: 17
type: SIMPLE_ASSIGN
$DER.limIntegrator.y = if limIntegrator.y < limIntegrator.outMin and limIntegrator.k * limIntegrator.u < 0.0 or limIntegrator.y > limIntegrator.outMax and limIntegrator.k * limIntegrator.u > 0.0 then 0.0 else limIntegrator.k * limIntegrator.u
*/
void Wassertank_eqFunction_17(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,17};
  modelica_boolean tmp0;
  modelica_boolean tmp1;
  modelica_boolean tmp2;
  modelica_boolean tmp3;
  relationhysteresis(data, &tmp0, (data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */), (data->simulationInfo->realParameter[3] /* limIntegrator.outMin PARAM */), 2, Less, LessZC);
  relationhysteresis(data, &tmp1, ((data->simulationInfo->realParameter[1] /* limIntegrator.k PARAM */)) * ((data->localData[0]->realVars[3] /* limIntegrator.u variable */)), 0.0, 3, Less, LessZC);
  relationhysteresis(data, &tmp2, (data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */), (data->simulationInfo->realParameter[2] /* limIntegrator.outMax PARAM */), 4, Greater, GreaterZC);
  relationhysteresis(data, &tmp3, ((data->simulationInfo->realParameter[1] /* limIntegrator.k PARAM */)) * ((data->localData[0]->realVars[3] /* limIntegrator.u variable */)), 0.0, 5, Greater, GreaterZC);
  (data->localData[0]->realVars[1] /* der(limIntegrator.y) STATE_DER */) = (((tmp0 && tmp1) || (tmp2 && tmp3))?0.0:((data->simulationInfo->realParameter[1] /* limIntegrator.k PARAM */)) * ((data->localData[0]->realVars[3] /* limIntegrator.u variable */)));
  TRACE_POP
}
/*
equation index: 18
type: SIMPLE_ASSIGN
y = limIntegrator.y
*/
void Wassertank_eqFunction_18(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,18};
  (data->localData[0]->realVars[6] /* y variable */) = (data->localData[0]->realVars[0] /* limIntegrator.y STATE(1) */);
  TRACE_POP
}
/*
equation index: 19
type: SIMPLE_ASSIGN
$whenCondition1 = y <= 0.001
*/
void Wassertank_eqFunction_19(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,19};
  modelica_boolean tmp4;
  relationhysteresis(data, &tmp4, (data->localData[0]->realVars[6] /* y variable */), 0.001, 0, LessEq, LessEqZC);
  (data->localData[0]->booleanVars[0] /* $whenCondition1 DISCRETE */) = tmp4;
  TRACE_POP
}
/*
equation index: 20
type: SIMPLE_ASSIGN
$whenCondition2 = y >= max_hoehe - 0.001
*/
void Wassertank_eqFunction_20(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,20};
  modelica_boolean tmp5;
  relationhysteresis(data, &tmp5, (data->localData[0]->realVars[6] /* y variable */), (data->simulationInfo->realParameter[5] /* max_hoehe PARAM */) - 0.001, 1, GreaterEq, GreaterEqZC);
  (data->localData[0]->booleanVars[1] /* $whenCondition2 DISCRETE */) = tmp5;
  TRACE_POP
}
/*
equation index: 21
type: SIMPLE_ASSIGN
$whenCondition3 = not y <= 0.001 and not y >= max_hoehe - 0.001
*/
void Wassertank_eqFunction_21(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,21};
  modelica_boolean tmp6;
  modelica_boolean tmp7;
  relationhysteresis(data, &tmp6, (data->localData[0]->realVars[6] /* y variable */), 0.001, 0, LessEq, LessEqZC);
  relationhysteresis(data, &tmp7, (data->localData[0]->realVars[6] /* y variable */), (data->simulationInfo->realParameter[5] /* max_hoehe PARAM */) - 0.001, 1, GreaterEq, GreaterEqZC);
  (data->localData[0]->booleanVars[2] /* $whenCondition3 DISCRETE */) = ((!tmp6) && (!tmp7));
  TRACE_POP
}
/*
equation index: 22
type: WHEN

when {$whenCondition3, $whenCondition2, $whenCondition1} then
  lowSignal = y <= 0.001;
end when;
*/
void Wassertank_eqFunction_22(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,22};
  modelica_boolean tmp8;
  if(((data->localData[0]->booleanVars[2] /* $whenCondition3 DISCRETE */) && !(data->simulationInfo->booleanVarsPre[2] /* $whenCondition3 DISCRETE */) /* edge */) || ((data->localData[0]->booleanVars[1] /* $whenCondition2 DISCRETE */) && !(data->simulationInfo->booleanVarsPre[1] /* $whenCondition2 DISCRETE */) /* edge */) || ((data->localData[0]->booleanVars[0] /* $whenCondition1 DISCRETE */) && !(data->simulationInfo->booleanVarsPre[0] /* $whenCondition1 DISCRETE */) /* edge */))
  {
    tmp8 = LessEq((data->localData[0]->realVars[6] /* y variable */),0.001);
    (data->localData[0]->booleanVars[5] /* lowSignal DISCRETE */) = tmp8;
  }
  TRACE_POP
}
/*
equation index: 23
type: SIMPLE_ASSIGN
y_low = lowSignal
*/
void Wassertank_eqFunction_23(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,23};
  (data->localData[0]->booleanVars[7] /* y_low DISCRETE */) = (data->localData[0]->booleanVars[5] /* lowSignal DISCRETE */);
  TRACE_POP
}
/*
equation index: 24
type: WHEN

when {$whenCondition3, $whenCondition2, $whenCondition1} then
  highSignal = if y <= 0.001 then false else y >= max_hoehe - 0.001;
end when;
*/
void Wassertank_eqFunction_24(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,24};
  modelica_boolean tmp9;
  modelica_boolean tmp10;
  modelica_boolean tmp11;
  modelica_boolean tmp12;
  if(((data->localData[0]->booleanVars[2] /* $whenCondition3 DISCRETE */) && !(data->simulationInfo->booleanVarsPre[2] /* $whenCondition3 DISCRETE */) /* edge */) || ((data->localData[0]->booleanVars[1] /* $whenCondition2 DISCRETE */) && !(data->simulationInfo->booleanVarsPre[1] /* $whenCondition2 DISCRETE */) /* edge */) || ((data->localData[0]->booleanVars[0] /* $whenCondition1 DISCRETE */) && !(data->simulationInfo->booleanVarsPre[0] /* $whenCondition1 DISCRETE */) /* edge */))
  {
    tmp9 = LessEq((data->localData[0]->realVars[6] /* y variable */),0.001);
    tmp11 = (modelica_boolean)tmp9;
    if(tmp11)
    {
      tmp12 = 0;
    }
    else
    {
      tmp10 = GreaterEq((data->localData[0]->realVars[6] /* y variable */),(data->simulationInfo->realParameter[5] /* max_hoehe PARAM */) - 0.001);
      tmp12 = tmp10;
    }
    (data->localData[0]->booleanVars[3] /* highSignal DISCRETE */) = tmp12;
  }
  TRACE_POP
}
/*
equation index: 25
type: SIMPLE_ASSIGN
y_high = highSignal
*/
void Wassertank_eqFunction_25(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,25};
  (data->localData[0]->booleanVars[6] /* y_high DISCRETE */) = (data->localData[0]->booleanVars[3] /* highSignal DISCRETE */);
  TRACE_POP
}

OMC_DISABLE_OPT
int Wassertank_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_DAE);
#endif

  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  Wassertank_functionLocalKnownVars(data, threadData);
  Wassertank_eqFunction_16(data, threadData);

  Wassertank_eqFunction_17(data, threadData);

  Wassertank_eqFunction_18(data, threadData);

  Wassertank_eqFunction_19(data, threadData);

  Wassertank_eqFunction_20(data, threadData);

  Wassertank_eqFunction_21(data, threadData);

  Wassertank_eqFunction_22(data, threadData);

  Wassertank_eqFunction_23(data, threadData);

  Wassertank_eqFunction_24(data, threadData);

  Wassertank_eqFunction_25(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_DAE);
#endif
  TRACE_POP
  return 0;
}


int Wassertank_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/* forwarded equations */
extern void Wassertank_eqFunction_16(DATA* data, threadData_t *threadData);
extern void Wassertank_eqFunction_17(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  {
    Wassertank_eqFunction_16(data, threadData);
    threadData->lastEquationSolved = 16;
  }
  {
    Wassertank_eqFunction_17(data, threadData);
    threadData->lastEquationSolved = 17;
  }
}

int Wassertank_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_FUNCTION_ODE);
#endif

  
  data->simulationInfo->callStatistics.functionODE++;
  
  Wassertank_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_FUNCTION_ODE);
#endif

  TRACE_POP
  return 0;
}

/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "Wassertank_12jac.h"
#include "Wassertank_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks Wassertank_callback = {
   (int (*)(DATA *, threadData_t *, void *)) Wassertank_performSimulation,    /* performSimulation */
   (int (*)(DATA *, threadData_t *, void *)) Wassertank_performQSSSimulation,    /* performQSSSimulation */
   Wassertank_updateContinuousSystem,    /* updateContinuousSystem */
   Wassertank_callExternalObjectDestructors,    /* callExternalObjectDestructors */
   NULL,    /* initialNonLinearSystem */
   NULL,    /* initialLinearSystem */
   NULL,    /* initialMixedSystem */
   #if !defined(OMC_NO_STATESELECTION)
   Wassertank_initializeStateSets,
   #else
   NULL,
   #endif    /* initializeStateSets */
   Wassertank_initializeDAEmodeData,
   Wassertank_functionODE,
   Wassertank_functionAlgebraics,
   Wassertank_functionDAE,
   Wassertank_functionLocalKnownVars,
   Wassertank_input_function,
   Wassertank_input_function_init,
   Wassertank_input_function_updateStartValues,
   Wassertank_data_function,
   Wassertank_output_function,
   Wassertank_setc_function,
   Wassertank_setb_function,
   Wassertank_function_storeDelayed,
   Wassertank_function_storeSpatialDistribution,
   Wassertank_function_initSpatialDistribution,
   Wassertank_updateBoundVariableAttributes,
   Wassertank_functionInitialEquations,
   1, /* useHomotopy - 0: local homotopy (equidistant lambda), 1: global homotopy (equidistant lambda), 2: new global homotopy approach (adaptive lambda), 3: new local homotopy approach (adaptive lambda)*/
   NULL,
   Wassertank_functionRemovedInitialEquations,
   Wassertank_updateBoundParameters,
   Wassertank_checkForAsserts,
   Wassertank_function_ZeroCrossingsEquations,
   Wassertank_function_ZeroCrossings,
   Wassertank_function_updateRelations,
   Wassertank_zeroCrossingDescription,
   Wassertank_relationDescription,
   Wassertank_function_initSample,
   Wassertank_INDEX_JAC_A,
   Wassertank_INDEX_JAC_B,
   Wassertank_INDEX_JAC_C,
   Wassertank_INDEX_JAC_D,
   Wassertank_INDEX_JAC_F,
   Wassertank_INDEX_JAC_H,
   Wassertank_initialAnalyticJacobianA,
   Wassertank_initialAnalyticJacobianB,
   Wassertank_initialAnalyticJacobianC,
   Wassertank_initialAnalyticJacobianD,
   Wassertank_initialAnalyticJacobianF,
   Wassertank_initialAnalyticJacobianH,
   Wassertank_functionJacA_column,
   Wassertank_functionJacB_column,
   Wassertank_functionJacC_column,
   Wassertank_functionJacD_column,
   Wassertank_functionJacF_column,
   Wassertank_functionJacH_column,
   Wassertank_linear_model_frame,
   Wassertank_linear_model_datarecovery_frame,
   Wassertank_mayer,
   Wassertank_lagrange,
   Wassertank_pickUpBoundsForInputsInOptimization,
   Wassertank_setInputData,
   Wassertank_getTimeGrid,
   Wassertank_symbolicInlineSystem,
   Wassertank_function_initSynchronous,
   Wassertank_function_updateSynchronous,
   Wassertank_function_equationsSynchronous,
   Wassertank_inputNames,
   Wassertank_dataReconciliationInputNames,
   Wassertank_dataReconciliationUnmeasuredVariables,
   NULL,
   NULL,
   NULL,
   -1,
   NULL,
   NULL,
   -1

};

#define _OMC_LIT_RESOURCE_0_name_data "Complex"
#define _OMC_LIT_RESOURCE_0_dir_data "C:/Users/proto/AppData/Roaming/.openmodelica/libraries/Complex 4.0.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_name,7,_OMC_LIT_RESOURCE_0_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir,77,_OMC_LIT_RESOURCE_0_dir_data);

#define _OMC_LIT_RESOURCE_1_name_data "Modelica"
#define _OMC_LIT_RESOURCE_1_dir_data "C:/Users/proto/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_name,8,_OMC_LIT_RESOURCE_1_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir,78,_OMC_LIT_RESOURCE_1_dir_data);

#define _OMC_LIT_RESOURCE_2_name_data "ModelicaServices"
#define _OMC_LIT_RESOURCE_2_dir_data "C:/Users/proto/AppData/Roaming/.openmodelica/libraries/ModelicaServices 4.0.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_name,16,_OMC_LIT_RESOURCE_2_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir,86,_OMC_LIT_RESOURCE_2_dir_data);

#define _OMC_LIT_RESOURCE_3_name_data "Wassertank"
#define _OMC_LIT_RESOURCE_3_dir_data "//Mac/Dropbox/HSD_Nextcloud/Lehrveranstaltungen/Sommersemester/Modellbildung_Simulation/OpenModelica"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_name,10,_OMC_LIT_RESOURCE_3_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir,100,_OMC_LIT_RESOURCE_3_dir_data);

static const MMC_DEFSTRUCTLIT(_OMC_LIT_RESOURCES,8,MMC_ARRAY_TAG) {MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir)}};
void Wassertank_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  threadData->localRoots[LOCAL_ROOT_SIMULATION_DATA] = data;
  data->callback = &Wassertank_callback;
  OpenModelica_updateUriMapping(threadData, MMC_REFSTRUCTLIT(_OMC_LIT_RESOURCES));
  data->modelData->modelName = "Wassertank";
  data->modelData->modelFilePrefix = "Wassertank";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "//Mac/Dropbox/HSD_Nextcloud/Lehrveranstaltungen/Sommersemester/Modellbildung_Simulation/OpenModelica";
  data->modelData->modelGUID = "{2329b184-797e-450e-b434-45e83bff911a}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "Wassertank_init.c"
    ;
  static const char contents_info[] =
    #include "Wassertank_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "Wassertank_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "Wassertank_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  data->modelData->modelDataXml.fileName = "Wassertank_info.json";
  data->modelData->resourcesDir = NULL;
  data->modelData->runTestsuite = 0;
  data->modelData->nStates = 1;
  data->modelData->nVariablesReal = 7;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 8;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 6;
  data->modelData->nParametersInteger = 1;
  data->modelData->nParametersBoolean = 4;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 2;
  data->modelData->nOutputVars = 3;
  data->modelData->nAliasReal = 0;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  data->modelData->nZeroCrossings = 5;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 6;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 0;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 37;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 0;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 6;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  data->modelData->nDelayExpressions = 0;
  data->modelData->nBaseClocks = 0;
  data->modelData->nSpatialDistributions = 0;
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
  data->modelData->nSetcVars = 0;
  data->modelData->ndataReconVars = 0;
  data->modelData->nSetbVars = 0;
  data->modelData->nRelatedBoundaryConditions = 0;
  data->modelData->linearizationDumpLanguage = OMC_LINEARIZE_DUMP_LANGUAGE_MODELICA;
}

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
int main(int argc, char**argv)
{
  /*
    Set the error functions to be used for simulation.
    The default value for them is 'functions' version. Change it here to 'simulation' versions
  */
  omc_assert = omc_assert_simulation;
  omc_assert_withEquationIndexes = omc_assert_simulation_withEquationIndexes;

  omc_assert_warning_withEquationIndexes = omc_assert_warning_simulation_withEquationIndexes;
  omc_assert_warning = omc_assert_warning_simulation;
  omc_terminate = omc_terminate_simulation;
  omc_throw = omc_throw_simulation;

  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  compiledWithSymSolver = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    Wassertank_setupDataStruc(&data, threadData);
    res = _main_initRuntimeAndSimulation(argc, argv, &data, threadData);
    if(res == 0) {
      res = _main_SimulationRuntime(argc, argv, &data, threadData);
    }
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  EXIT(res);
  return res;
}

#ifdef __cplusplus
}
#endif


